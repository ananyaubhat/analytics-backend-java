package com.example.analytics.service;

import com.example.analytics.entity.EventEntity;
import com.example.analytics.entity.AppEntity;
import com.example.analytics.repository.EventRepository;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.util.List;
import java.util.UUID;
import com.example.analytics.repository.AppRepository;

@Service
public class EventService {
    private final EventRepository eventRepo;
    private final AppRepository appRepo;

    public EventService(EventRepository eventRepo, AppRepository appRepo) {
        this.eventRepo = eventRepo;
        this.appRepo = appRepo;
    }

    public void ingestEvent(UUID appId, String eventName, String url, String referrer, String device, String ip, String userId, Instant timestamp, String metadataJson) {
        AppEntity app = appRepo.findById(appId).orElseThrow();
        EventEntity e = new EventEntity();
        e.setApp(app);
        e.setEventName(eventName);
        e.setUrl(url);
        e.setReferrer(referrer);
        e.setDevice(device);
        e.setIpAddress(ip);
        e.setUserId(userId);
        e.setTimestamp(timestamp==null?Instant.now():timestamp);
        e.setMetadataJson(metadataJson);
        eventRepo.save(e);
    }

    public java.util.Map<String, Object> getEventSummary(UUID appId, String eventName, Instant start, Instant end) {
        Instant s = start == null ? Instant.EPOCH : start;
        Instant e = end == null ? Instant.now() : end;
        List<EventEntity> list = eventRepo.findByAppIdAndEventNameAndTimestampBetween(appId, eventName, s, e);
        long count = list.size();
        long uniqueUsers = list.stream().map(ev -> ev.getUserId() != null ? ev.getUserId() : ev.getIpAddress()).distinct().count();
        long mobile = list.stream().filter(ev -> "mobile".equalsIgnoreCase(ev.getDevice())).count();
        long desktop = list.stream().filter(ev -> "desktop".equalsIgnoreCase(ev.getDevice())).count();
        var map = new java.util.HashMap<String,Object>();
        map.put("event", eventName);
        map.put("count", count);
        map.put("uniqueUsers", uniqueUsers);
        var deviceData = new java.util.HashMap<String, Long>();
        deviceData.put("mobile", mobile);
        deviceData.put("desktop", desktop);
        map.put("deviceData", deviceData);
        return map;
    }
}
