package com.example.analytics.service;

import com.example.analytics.entity.ApiKeyEntity;
import com.example.analytics.entity.AppEntity;
import com.example.analytics.repository.ApiKeyRepository;
import com.example.analytics.repository.AppRepository;
import com.example.analytics.util.KeyUtil;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

@Service
public class ApiKeyService {
    private final ApiKeyRepository apiKeyRepo;
    private final AppRepository appRepo;
    private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();

    public ApiKeyService(ApiKeyRepository apiKeyRepo, AppRepository appRepo) {
        this.apiKeyRepo = apiKeyRepo;
        this.appRepo = appRepo;
    }

    public String registerAppAndGenerateKey(String name, String ownerEmail, Integer expiresInDays) {
        AppEntity app = new AppEntity();
        app.setName(name);
        app.setOwnerEmail(ownerEmail);
        appRepo.save(app);

        String rawKey = KeyUtil.generateKey();
        String hash = encoder.encode(rawKey);

        ApiKeyEntity key = new ApiKeyEntity();
        key.setApp(app);
        key.setKeyHash(hash);
        if (expiresInDays != null) {
            key.setExpiresAt(Instant.now().plus(expiresInDays, ChronoUnit.DAYS));
        }
        apiKeyRepo.save(key);
        return rawKey;
    }

    public ApiKeyEntity findByRawKey(String rawKey) {
        var keys = apiKeyRepo.findAll();
        for (ApiKeyEntity k : keys) {
            if (!k.isRevoked() && encoder.matches(rawKey, k.getKeyHash())) return k;
        }
        return null;
    }

    public void revokeKey(java.util.UUID keyId) {
        apiKeyRepo.findById(keyId).ifPresent(k -> {
            k.setRevoked(true);
            apiKeyRepo.save(k);
        });
    }
}
