package com.example.analytics.controller;

import com.example.analytics.service.ApiKeyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final ApiKeyService apiKeyService;

    public AuthController(ApiKeyService apiKeyService) {
        this.apiKeyService = apiKeyService;
    }

    public static record RegisterRequest(String name, String ownerEmail, Integer expiresInDays) {}

    @PostMapping("/register")
    public ResponseEntity<Map<String, String>> register(@RequestBody RegisterRequest req) {
        String rawKey = apiKeyService.registerAppAndGenerateKey(req.name(), req.ownerEmail(), req.expiresInDays());
        return ResponseEntity.ok(Map.of("apiKey", rawKey));
    }

    @PostMapping("/revoke")
    public ResponseEntity<Map<String, Object>> revoke(@RequestBody Map<String, String> body) {
        try {
            java.util.UUID keyId = java.util.UUID.fromString(body.get("keyId"));
            apiKeyService.revokeKey(keyId);
            return ResponseEntity.ok(Map.of("ok", true));
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body(Map.of("error", ex.getMessage()));
        }
    }
}
