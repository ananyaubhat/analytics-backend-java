package com.example.analytics.controller;

import com.example.analytics.entity.ApiKeyEntity;
import com.example.analytics.service.EventService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;

@RestController
@RequestMapping("/api/analytics")
public class AnalyticsController {

    private final EventService eventService;

    public AnalyticsController(EventService eventService) {
        this.eventService = eventService;
    }

    public static record CollectRequest(String event, String url, String referrer, String device,
                                        String ipAddress, String timestamp, Map<String,Object> metadata, String userId) {}

    @PostMapping("/collect")
    public ResponseEntity<Map<String, Object>> collect(@RequestBody CollectRequest req, HttpServletRequest servletReq) {
        ApiKeyEntity key = (ApiKeyEntity) servletReq.getAttribute("apiKeyEntity");
        if (key == null) return ResponseEntity.status(401).body(Map.of("message", "API key required"));

        Instant ts = null;
        if (req.timestamp() != null) {
            try { ts = Instant.parse(req.timestamp()); } catch (Exception ex) { ts = Instant.now(); }
        }

        String metadataJson = "{}";
        try {
            metadataJson = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(req.metadata());
        } catch (Exception ignored) {}

        eventService.ingestEvent(key.getApp().getId(), req.event(), req.url(), req.referrer(),
                req.device(), req.ipAddress(), req.userId(), ts, metadataJson);

        return ResponseEntity.ok(Map.of("ok", true));
    }

    @GetMapping("/event-summary")
    public ResponseEntity<?> eventSummary(@RequestParam String event,
                                          @RequestParam(required = false) String startDate,
                                          @RequestParam(required = false) String endDate,
                                          HttpServletRequest servletReq) {
        ApiKeyEntity key = (ApiKeyEntity) servletReq.getAttribute("apiKeyEntity");
        if (key == null) return ResponseEntity.status(401).body(Map.of("message", "API key required"));

        Instant s = null, e = null;
        try { if (startDate != null) s = Instant.parse(startDate); } catch (Exception ex) { s=null; }
        try { if (endDate != null) e = Instant.parse(endDate); } catch (Exception ex) { e=null; }

        var map = eventService.getEventSummary(key.getApp().getId(), event, s, e);
        return ResponseEntity.ok(map);
    }

    @GetMapping("/user-stats")
    public ResponseEntity<?> userStats(@RequestParam String userId) {
        return ResponseEntity.ok(Map.of("userId", userId, "totalEvents", 0));
    }
}
