package com.example.analytics.repository;

import com.example.analytics.entity.AppEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;

public interface AppRepository extends JpaRepository<AppEntity, UUID> {
}
