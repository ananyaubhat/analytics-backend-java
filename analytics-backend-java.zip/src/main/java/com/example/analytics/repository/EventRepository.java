package com.example.analytics.repository;

import com.example.analytics.entity.EventEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.UUID;
import java.time.Instant;
import java.util.List;

public interface EventRepository extends JpaRepository<EventEntity, UUID> {
    List<EventEntity> findByAppIdAndEventNameAndTimestampBetween(UUID appId, String eventName, Instant start, Instant end);
    List<EventEntity> findByUserId(String userId);
}
