package com.example.analytics.config;

import com.example.analytics.service.ApiKeyService;
import com.example.analytics.entity.ApiKeyEntity;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import java.io.IOException;

@Component
public class ApiKeyFilter implements Filter {

    private final ApiKeyService apiKeyService;

    public ApiKeyFilter(ApiKeyService apiKeyService) {
        this.apiKeyService = apiKeyService;
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getRequestURI();
        if (path.startsWith("/api/auth")) {
            chain.doFilter(req, res);
            return;
        }

        String apiKey = request.getHeader("X-API-KEY");
        if (apiKey == null || apiKey.isBlank()) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{"message":"API key required in X-API-KEY header"}");
            return;
        }

        ApiKeyEntity key = apiKeyService.findByRawKey(apiKey);
        if (key == null || key.isRevoked() || (key.getExpiresAt() != null && key.getExpiresAt().isBefore(java.time.Instant.now()))) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{"message":"Invalid or expired API key"}");
            return;
        }

        request.setAttribute("apiKeyEntity", key);
        chain.doFilter(req, res);
    }
}
