package com.example.analytics.util;

import java.util.UUID;

public class KeyUtil {
    public static String generateKey() {
        return UUID.randomUUID().toString() + "." + UUID.randomUUID().toString();
    }
    public static String extractKeyId(String raw) {
        if (raw == null) return null;
        String[] parts = raw.split("\\.");
        return parts.length>0 ? parts[0] : null;
    }
}
